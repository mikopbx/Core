#!/usr/bin/env python3
"""
Basic PJSUA Library Verification Tests

This module verifies that PJSUA library can successfully:
1. Register SIP extensions to MikoPBX
2. Make basic calls between extensions
3. Handle call lifecycle (dial, answer, hangup)

The tests use fixtures from tests/api/fixtures/employee.json with extensions:
- 201 (smith.james)
- 202 (brown.brandon)
- 203 (collins.melanie)
"""

import asyncio
import logging
import pytest
import pytest_asyncio

from conftest import (
    api_client,
    get_extension_secret,
    convert_employee_fixture_to_api_format,
    assert_api_success
)
from pjsua_helper import PJSUAManager, get_mikopbx_ip

# Configure logging for detailed output
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@pytest_asyncio.fixture
async def pjsua_manager():
    """
    Create PJSUA manager instance with MikoPBX server IP

    Returns:
        PJSUAManager instance connected to MikoPBX
    """
    server_ip = await get_mikopbx_ip()
    logger.info(f"Creating PJSUA manager for server: {server_ip}")

    manager = PJSUAManager(server_ip)
    yield manager

    # Cleanup all endpoints
    logger.info("Cleaning up PJSUA endpoints")
    await manager.cleanup_all()


async def ensure_extension_exists(api_client, extension_number: str) -> str:
    """
    Ensure extension exists in MikoPBX, create if needed.

    Args:
        api_client: MikoPBX API client
        extension_number: Extension number (e.g., '201')

    Returns:
        SIP secret for the extension
    """
    # Try to get secret from existing extension
    secret = get_extension_secret(extension_number, api_client)

    if secret:
        logger.info(f"Extension {extension_number} exists with secret: {secret}")
        return secret

    # Extension doesn't exist, create it from fixture
    logger.info(f"Extension {extension_number} not found, creating from fixture")

    # Load employee fixture and create extension
    employee_key = {
        '201': 'smith.james',
        '202': 'brown.brandon',
        '203': 'collins.melanie'
    }.get(extension_number)

    if not employee_key:
        raise ValueError(f"No fixture data for extension {extension_number}")

    # Convert fixture to API format
    extension_data = convert_employee_fixture_to_api_format(employee_key)

    # Create extension via API
    response = api_client.post('extensions/create', extension_data)
    assert_api_success(response)

    # Get secret from created extension
    secret = get_extension_secret(extension_number, api_client)
    if not secret:
        raise RuntimeError(f"Failed to get secret for created extension {extension_number}")

    logger.info(f"Created extension {extension_number} with secret: {secret}")
    return secret


@pytest.mark.asyncio
async def test_pjsua_registration(api_client, pjsua_manager):
    """
    Test PJSUA library can register extension 201 to MikoPBX

    This test verifies:
    1. Extension 201 exists or can be created
    2. PJSUA can initialize SIP endpoint
    3. SIP registration to MikoPBX succeeds
    4. Registration status is confirmed
    5. Unregistration succeeds

    Expected behavior:
    - Registration completes within timeout (10s)
    - Registration status code is 200 OK
    - Extension remains registered until explicit unregister
    """
    logger.info("=" * 80)
    logger.info("TEST: PJSUA Registration to MikoPBX")
    logger.info("=" * 80)

    # Ensure extension 201 exists
    extension = "201"
    password = await ensure_extension_exists(api_client, extension)
    logger.info(f"Using extension {extension} with password: {password}")

    # Create and register endpoint
    logger.info(f"Creating PJSUA endpoint for extension {extension}")
    endpoint = await pjsua_manager.create_endpoint(
        extension=extension,
        password=password,
        auto_register=True
    )

    # Verify registration succeeded
    assert endpoint.is_registered, "Extension should be registered"
    logger.info(f"✓ Extension {extension} successfully registered to MikoPBX")

    # Verify endpoint is in manager's registry
    retrieved_endpoint = pjsua_manager.get_endpoint(extension)
    assert retrieved_endpoint is not None, "Endpoint should be in manager registry"
    assert retrieved_endpoint == endpoint, "Retrieved endpoint should match created endpoint"
    logger.info(f"✓ Endpoint found in manager registry")

    # Unregister
    logger.info(f"Unregistering extension {extension}")
    unregister_result = await endpoint.unregister()
    assert unregister_result, "Unregistration should succeed"
    assert not endpoint.is_registered, "Extension should not be registered after unregister"
    logger.info(f"✓ Extension {extension} successfully unregistered")

    logger.info("=" * 80)
    logger.info("TEST PASSED: PJSUA Registration")
    logger.info("=" * 80)


@pytest.mark.asyncio
async def test_pjsua_basic_call(api_client, pjsua_manager, cdr_baseline):
    """
    Test PJSUA library can make basic call from 201 to 202

    This test verifies:
    1. Extensions 201 and 202 exist or can be created
    2. Both endpoints can register to MikoPBX
    3. Extension 201 can dial extension 202
    4. Call establishment succeeds (CONFIRMED state)
    5. CDR record is created for the call
    6. Call can be hung up successfully
    7. Both endpoints can unregister

    Expected behavior:
    - Both extensions register successfully
    - Call completes within timeout (30s)
    - Call reaches CONFIRMED state (answered)
    - CDR record contains correct src/dst extensions
    - Hangup completes cleanly
    """
    logger.info("=" * 80)
    logger.info("TEST: PJSUA Basic Call from 201 to 202")
    logger.info("=" * 80)

    # Get CDR baseline before test
    baseline_id = cdr_baseline()
    logger.info(f"CDR baseline ID: {baseline_id}")

    # Ensure extensions exist
    ext_201 = "201"
    ext_202 = "202"

    password_201 = await ensure_extension_exists(api_client, ext_201)
    password_202 = await ensure_extension_exists(api_client, ext_202)

    logger.info(f"Using extensions: {ext_201} (secret: {password_201}), {ext_202} (secret: {password_202})")

    # Create and register both endpoints
    logger.info("Creating and registering both endpoints")
    endpoint_201 = await pjsua_manager.create_endpoint(
        extension=ext_201,
        password=password_201,
        auto_register=True
    )

    endpoint_202 = await pjsua_manager.create_endpoint(
        extension=ext_202,
        password=password_202,
        auto_register=True
    )

    assert endpoint_201.is_registered, "Extension 201 should be registered"
    assert endpoint_202.is_registered, "Extension 202 should be registered"
    logger.info("✓ Both extensions registered successfully")

    try:
        # Make call from 201 to 202
        logger.info(f"Dialing from {ext_201} to {ext_202}")
        call_result = await endpoint_201.dial(destination=ext_202, timeout=30)

        assert call_result, "Call should be established"
        assert endpoint_201.call_active, "Caller should have active call"
        logger.info("✓ Call established successfully")

        # Keep call active for a moment
        logger.info("Keeping call active for 3 seconds")
        await asyncio.sleep(3)

        # Hangup call
        logger.info("Hanging up call")
        hangup_result = await endpoint_201.hangup()
        assert hangup_result, "Hangup should succeed"
        assert not endpoint_201.call_active, "Call should not be active after hangup"
        logger.info("✓ Call hung up successfully")

        # Wait for CDR to be written
        logger.info("Waiting for CDR record to be written (2 seconds)")
        await asyncio.sleep(2)

        # Verify CDR record was created
        logger.info("Checking CDR records")
        cdr_records = cdr_baseline.get_records(baseline_id)

        logger.info(f"Found {len(cdr_records)} CDR records after baseline")
        for record in cdr_records:
            logger.info(f"  CDR: {record.get('src')} -> {record.get('dst')}, "
                       f"duration: {record.get('billsec')}s, "
                       f"disposition: {record.get('disposition')}")

        # Find call record for 201 -> 202
        call_record = None
        for record in cdr_records:
            if record.get('src') == ext_201 and record.get('dst') == ext_202:
                call_record = record
                break

        assert call_record is not None, f"CDR record for call {ext_201} -> {ext_202} should exist"
        logger.info(f"✓ CDR record found: {call_record}")

    finally:
        # Cleanup: unregister both endpoints
        logger.info("Unregistering endpoints")
        await endpoint_201.unregister()
        await endpoint_202.unregister()
        logger.info("✓ Both endpoints unregistered")

    logger.info("=" * 80)
    logger.info("TEST PASSED: PJSUA Basic Call")
    logger.info("=" * 80)


if __name__ == '__main__':
    # Run tests directly with pytest
    pytest.main([__file__, '-v', '-s'])
