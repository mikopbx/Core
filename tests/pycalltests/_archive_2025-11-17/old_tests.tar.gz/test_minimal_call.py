#!/usr/bin/env python3
"""Minimal PJSUA test to isolate the assertion issue"""
import sys
import os
from pathlib import Path

# Set library path
pjsua2_lib_path = str(Path(__file__).parent / "pjsua2_lib")
if 'DYLD_LIBRARY_PATH' in os.environ:
    os.environ['DYLD_LIBRARY_PATH'] = f"{pjsua2_lib_path}:{os.environ['DYLD_LIBRARY_PATH']}"
else:
    os.environ['DYLD_LIBRARY_PATH'] = pjsua2_lib_path

sys.path.insert(0, pjsua2_lib_path)

print("Step 1: About to import pjsua2")
import pjsua2 as pj
print("Step 2: pjsua2 imported successfully")

print("Step 3: Creating Endpoint")
ep = pj.Endpoint()
print("Step 4: Calling libCreate()")
ep.libCreate()
print("Step 5: libCreate() completed")

ep_cfg = pj.EpConfig()
ep_cfg.uaConfig.maxCalls = 10

print("Step 6: Calling libInit()")
ep.libInit(ep_cfg)
print("Step 7: libInit() completed")

# Create transport BEFORE creating Call
print("Step 7a: Creating transport")
transport_cfg = pj.TransportConfig()
transport_cfg.port = 0
ep.transportCreate(pj.PJSIP_TRANSPORT_UDP, transport_cfg)
print("Step 7b: Transport created")

print("Step 7c: Calling libStart()")
ep.libStart()
print("Step 7d: libStart() completed")

print("Step 8: Creating Account")

class TestAccount(pj.Account):
    def __init__(self):
        print("Step 8a: In TestAccount.__init__")
        pj.Account.__init__(self)
        print("Step 8b: pj.Account.__init__() completed")

acc = TestAccount()
print("Step 9: Account created")

print("Step 10: Creating Call with PJSUA_INVALID_ID")

class TestCall(pj.Call):
    def __init__(self, account):
        print("Step 10a: In TestCall.__init__, about to call pj.Call.__init__")
        pj.Call.__init__(self, account, pj.PJSUA_INVALID_ID)
        print("Step 10b: pj.Call.__init__() completed - THIS SHOULD NOT PRINT IF ASSERTION FAILS")

try:
    call = TestCall(acc)
    print("Step 11: Call created successfully!")
except Exception as e:
    print(f"Step 11: Call creation failed with: {e}")
    import traceback
    traceback.print_exc()

print("\n✅ Test completed without crash!")
