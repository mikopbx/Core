#!/usr/bin/env python3
"""
Test call from extension 201 to 228 using PJSUA2 inside MikoPBX container.
"""
import sys
sys.path.insert(0, "/tmp/pjsua2_lib")
import pjsua2 as pj
import time

class MyCall(pj.Call):
    def __init__(self, acc, call_id=pj.PJSUA_INVALID_ID):
        pj.Call.__init__(self, acc, call_id)

    def onCallState(self, prm):
        ci = self.getInfo()
        print(f"[CALL] State: {ci.stateText}")

class MyAccount(pj.Account):
    def __init__(self):
        pj.Account.__init__(self)

    def onRegState(self, prm):
        ai = self.getInfo()
        print(f"[REG] {ai.regStatusText}")

# Create endpoint
print("="*60)
print("CALLING 228 from 201 - ANSWER YOUR PHONE!")
print("="*60)

ep = pj.Endpoint()
ep.libCreate()
ep_cfg = pj.EpConfig()
ep_cfg.logConfig.level = 3

# Configure media - use null audio device for container
ep_cfg.medConfig.noVad = True
ep_cfg.medConfig.ecTailLen = 0
ep_cfg.medConfig.channelCount = 1
ep_cfg.medConfig.clockRate = 8000

ep.libInit(ep_cfg)

# Set null audio device to avoid ALSA errors
ep.audDevManager().setNullDev()

# Create transport
sipTpConfig = pj.TransportConfig()
sipTpConfig.port = 0
ep.transportCreate(pj.PJSIP_TRANSPORT_UDP, sipTpConfig)
ep.libStart()

print(f"\n[PJSUA2] Version: {ep.libVersion().full}")

# Register as 201
acc_cfg = pj.AccountConfig()
acc_cfg.idUri = "sip:201@192.168.107.2"
acc_cfg.regConfig.registrarUri = "sip:192.168.107.2"
cred = pj.AuthCredInfo("digest", "asterisk", "201", 0, "5b66b92d5714f921cfcde78a4fda0f58")
acc_cfg.sipConfig.authCreds.append(cred)

acc = MyAccount()
acc.create(acc_cfg)

print("[REG] Registering as 201...")
time.sleep(3)

# Make call to 228
print("\n[CALL] Calling 228 - ANSWER YOUR PHONE NOW!")
call = MyCall(acc)
call_param = pj.CallOpParam()
call.makeCall("sip:228@192.168.107.2", call_param)

print("[CALL] Waiting for answer (30 seconds)...")
time.sleep(30)

print("\n[CALL] Hanging up...")
call_op = pj.CallOpParam()
call.hangup(call_op)
time.sleep(2)

print("[CLEANUP] Done!")
ep.libDestroy()
