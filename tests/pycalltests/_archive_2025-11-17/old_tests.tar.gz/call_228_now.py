#!/usr/bin/env python3
import sys, os, asyncio
from pathlib import Path

test_dir = Path(__file__).parent
pjsua2_lib_path = str(test_dir / "pjsua2_lib")
os.environ['DYLD_LIBRARY_PATH'] = f"{pjsua2_lib_path}:{os.environ.get('DYLD_LIBRARY_PATH', '')}"
sys.path.insert(0, pjsua2_lib_path)
sys.path.insert(0, str(test_dir.parent / "api"))

from pjsua_helper import PJSUAManager, get_mikopbx_ip

async def main():
    print("\n" + "="*60)
    print("📞 CALLING EXTENSION 228 - ANSWER YOUR PHONE!")
    print("="*60 + "\n")
    
    server_ip = await get_mikopbx_ip()
    print(f"🌐 Server: {server_ip}")
    
    manager = PJSUAManager(server_ip)
    await manager.initialize()
    
    print("🔑 Registering extension 202...")
    endpoint = await manager.create_endpoint("202", "e72b3aea6e4f2a8560adb33cb9bfa5dd", auto_register=True)
    print("✅ Registered!\n")
    
    print("📞 Dialing 228... ANSWER NOW!\n")
    
    if await endpoint.dial("228", timeout=60):
        print("✅ CALL CONNECTED!")
        print("🎙️  Talk for 30 seconds...\n")
        for i in range(30):
            await asyncio.sleep(1)
            if (i+1) % 5 == 0: 
                print(f"   ⏱️  {i+1}/30 seconds...")
        print("\n📴 Hanging up...")
        await endpoint.hangup()
        print("✅ Call ended")
    else:
        print("❌ Call failed - no answer or timeout")
    
    await manager.cleanup_all()
    print("\n✅ Done!\n")

asyncio.run(main())
