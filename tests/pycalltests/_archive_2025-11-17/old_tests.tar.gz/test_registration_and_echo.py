#!/usr/bin/env python3
"""
Test SIP Registration and Echo Test Calls

This test validates:
1. SIP registration using different transports (UDP, TCP, TLS)
2. Making test calls to echo service (*60)
3. Proper call flow and CDR record creation

Test Scenarios:
- Registration via UDP (extension 201)
- Registration via TCP (extension 202)
- Registration via TLS (extension 230)
- Echo test call through each transport
"""

import pytest
import pytest_asyncio
import asyncio
import logging
from pjsua_helper import PJSUAManager, get_mikopbx_ip

logger = logging.getLogger(__name__)

# Test extensions configuration (from database)
TEST_EXTENSIONS = {
    'udp': {
        'extension': '201',
        'password': '5b66b92d5714f921cfcde78a4fda0f58',
        'transport': 'udp'
    },
    'tcp': {
        'extension': '202',
        'password': 'e72b3aea6e4f2a8560adb33cb9bfa5dd',
        'transport': 'tcp'
    },
    'tls': {
        'extension': '230',
        'password': 'R2I4R1BjRDFlQmRPeHQ0cmEwWDI3a0xp',
        'transport': 'tls'
    }
}

ECHO_TEST_EXTENSION = '10003246'  # Echo test service in MikoPBX


@pytest_asyncio.fixture
async def mikopbx_ip():
    """Get MikoPBX server IP address"""
    ip = await get_mikopbx_ip()
    logger.info(f"Using MikoPBX IP: {ip}")
    return ip


@pytest_asyncio.fixture
async def pjsua_manager(mikopbx_ip):
    """Create PJSUA manager instance for tests"""
    manager = PJSUAManager(server_ip=mikopbx_ip)
    await manager.initialize()  # Initialize event handler in correct async context
    yield manager
    # Cleanup endpoints (event handler stays running)
    await manager.cleanup_all()


@pytest.mark.asyncio
@pytest.mark.parametrize("transport", ["udp", "tcp"])
async def test_registration_by_transport(pjsua_manager, transport, cdr_baseline):
    """
    Test SIP registration using different transports

    This test:
    1. Creates PJSUA endpoint
    2. Registers extension with specified transport
    3. Verifies registration successful
    4. Unregisters endpoint
    """
    config = TEST_EXTENSIONS[transport]

    logger.info(f"\n{'='*60}")
    logger.info(f"Testing registration via {transport.upper()}")
    logger.info(f"Extension: {config['extension']}")
    logger.info(f"{'='*60}\n")

    # Create and register endpoint
    endpoint = await pjsua_manager.create_endpoint(
        extension=config['extension'],
        password=config['password'],
        auto_register=True
    )

    # Verify registration successful
    assert endpoint.is_registered, f"Failed to register via {transport}"
    logger.info(f"✓ Registration successful via {transport}")

    # Wait a bit to ensure registration is stable
    await asyncio.sleep(1)

    # Unregister
    await endpoint.unregister()
    assert not endpoint.is_registered, f"Failed to unregister via {transport}"
    logger.info(f"✓ Unregistration successful via {transport}")


@pytest.mark.asyncio
@pytest.mark.parametrize("transport", ["udp", "tcp"])
async def test_echo_call_by_transport(pjsua_manager, transport, cdr_baseline, api_client):
    """
    Test making call to echo service using different transports

    This test:
    1. Registers extension with specified transport
    2. Makes call to echo test service (*60)
    3. Verifies call is established
    4. Hangs up after short duration
    5. Verifies CDR record created
    """
    config = TEST_EXTENSIONS[transport]

    logger.info(f"\n{'='*60}")
    logger.info(f"Testing echo call via {transport.upper()}")
    logger.info(f"Extension: {config['extension']} → {ECHO_TEST_EXTENSION}")
    logger.info(f"{'='*60}\n")

    # Get CDR baseline before call
    baseline_id = cdr_baseline()

    # Create and register endpoint
    endpoint = await pjsua_manager.create_endpoint(
        extension=config['extension'],
        password=config['password'],
        auto_register=True
    )

    assert endpoint.is_registered, f"Failed to register via {transport}"
    logger.info(f"✓ Extension {config['extension']} registered via {transport}")

    # Make call to echo test
    call_success = await endpoint.dial(
        destination=ECHO_TEST_EXTENSION,
        timeout=15
    )

    assert call_success, f"Failed to establish call via {transport}"
    logger.info(f"✓ Call established to {ECHO_TEST_EXTENSION}")

    # Keep call active for 3 seconds (enough for echo test)
    logger.info("Waiting 3 seconds for echo test...")
    await asyncio.sleep(3)

    # Hangup
    hangup_success = await endpoint.hangup()
    assert hangup_success, "Failed to hangup call"
    logger.info("✓ Call disconnected")

    # Wait for CDR record to be written
    await asyncio.sleep(2)

    # Verify CDR record created
    cdr_records = cdr_baseline.get_records(baseline_id)
    logger.info(f"Found {len(cdr_records)} CDR record(s) after baseline")

    # Find our call in CDR
    our_call = None
    for record in cdr_records:
        if record.get('src') == config['extension'] and record.get('dst') == ECHO_TEST_EXTENSION:
            our_call = record
            break

    assert our_call is not None, f"CDR record not found for call from {config['extension']} to {ECHO_TEST_EXTENSION}"
    logger.info(f"✓ CDR record created: {our_call.get('id')}")
    logger.info(f"  Duration: {our_call.get('billsec')} seconds")
    logger.info(f"  Disposition: {our_call.get('disposition')}")

    # Cleanup
    await endpoint.unregister()
    logger.info(f"✓ Test completed successfully via {transport}")


@pytest.mark.asyncio
@pytest.mark.skip(reason="TLS support requires additional PJSUA configuration - implement later")
async def test_registration_tls(pjsua_manager, cdr_baseline):
    """
    Test SIP registration using TLS transport

    NOTE: TLS requires additional PJSUA configuration:
    - TLS transport creation with certificates
    - Proper port configuration (typically 5061)
    - Certificate verification settings

    This test is skipped until TLS configuration is implemented.
    """
    config = TEST_EXTENSIONS['tls']

    logger.info(f"\n{'='*60}")
    logger.info(f"Testing registration via TLS")
    logger.info(f"Extension: {config['extension']}")
    logger.info(f"{'='*60}\n")

    # TODO: Implement TLS transport creation in PJSUAManager
    # TODO: Configure TLS certificates
    # TODO: Test registration

    pytest.skip("TLS support not yet implemented")


@pytest.mark.asyncio
async def test_multiple_simultaneous_registrations(pjsua_manager):
    """
    Test multiple simultaneous registrations

    This test verifies that multiple extensions can be registered
    at the same time without conflicts.
    """
    logger.info(f"\n{'='*60}")
    logger.info("Testing multiple simultaneous registrations")
    logger.info(f"{'='*60}\n")

    # Register multiple extensions simultaneously
    endpoints = []

    for transport_name, config in TEST_EXTENSIONS.items():
        if transport_name == 'tls':
            continue  # Skip TLS for now

        logger.info(f"Registering {config['extension']} via {transport_name}...")
        endpoint = await pjsua_manager.create_endpoint(
            extension=config['extension'],
            password=config['password'],
            auto_register=True
        )
        endpoints.append(endpoint)
        assert endpoint.is_registered, f"Failed to register {config['extension']}"

    logger.info(f"✓ All {len(endpoints)} extensions registered successfully")

    # Verify all still registered
    for endpoint in endpoints:
        assert endpoint.is_registered, "Registration lost during test"

    logger.info("✓ All registrations remain stable")

    # Cleanup
    for endpoint in endpoints:
        await endpoint.unregister()

    logger.info("✓ All extensions unregistered successfully")
