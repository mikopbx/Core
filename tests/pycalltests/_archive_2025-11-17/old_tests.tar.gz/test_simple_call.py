#!/usr/bin/env python3
"""Simple test to register and make a call with PJSUA"""
import asyncio
import sys
import os
from pathlib import Path

# Set library path
pjsua2_lib_path = str(Path(__file__).parent / "pjsua2_lib")
if 'DYLD_LIBRARY_PATH' in os.environ:
    os.environ['DYLD_LIBRARY_PATH'] = f"{pjsua2_lib_path}:{os.environ['DYLD_LIBRARY_PATH']}"
else:
    os.environ['DYLD_LIBRARY_PATH'] = pjsua2_lib_path

sys.path.insert(0, pjsua2_lib_path)
sys.path.insert(0, str(Path(__file__).parent.parent / "api"))

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Simple Account class - will be defined after importing pjsua2
SimpleAccount = None
SimpleCall = None

def init_classes():
    """Initialize PJSUA classes after import"""
    global SimpleAccount, SimpleCall
    import pjsua2 as pj

    class SimpleAccount(pj.Account):
        def __init__(self):
            pj.Account.__init__(self)
            self.registered = False

        def onRegState(self, prm):
            print(f"🔔 onRegState callback FIRED!")
            try:
                ai = self.getInfo()
                print(f"Registration status: {ai.regStatus}")
                print(f"Before set: self.registered = {self.registered}")
                if ai.regStatus == 200:
                    self.registered = True
                    print(f"✅ After set: self.registered = {self.registered}")
                else:
                    print(f"Status is not 200, status={ai.regStatus}")
            except Exception as e:
                print(f"❌ Exception in onRegState: {e}")
                import traceback
                traceback.print_exc()

    # Simple Call class - must subclass pj.Call, cannot use base class directly
    class SimpleCall(pj.Call):
        def __init__(self, account):
            pj.Call.__init__(self, account, pj.PJSUA_INVALID_ID)
            self.connected = False

        def onCallState(self, prm):
            try:
                ci = self.getInfo()
                print(f"📞 Call state: {ci.stateText}")
                if ci.state == pj.PJSIP_INV_STATE_CONFIRMED:
                    self.connected = True
                    print("✅ Call CONFIRMED!")
            except Exception as e:
                print(f"❌ Error in onCallState: {e}")

def main():
    # Get secrets from API
    print("\n=== Getting extension secrets from MikoPBX ===")

    # Use hardcoded secrets from fixtures
    secret_202 = "e72b3aea6e4f2a8560adb33cb9bfa5dd"  # brown.brandon (202)
    secret_228 = "bEN4NUw0MEJ4Y1BYMWQ0SUFGTGlXVFFy"  # anton.pasutin (228)

    print(f"Extension 202 secret: {secret_202}")
    print(f"Extension 228 secret: {secret_228}")

    # Initialize endpoint
    ep = pj.Endpoint()
    ep.libCreate()

    # Configure with manual polling (worker threads cause Call constructor assertion)
    ep_cfg = pj.EpConfig()
    ep_cfg.uaConfig.threadCnt = 0  # No worker threads
    ep_cfg.uaConfig.mainThreadOnly = True  # Manual event polling required
    ep_cfg.uaConfig.maxCalls = 10  # Allow up to 10 simultaneous calls

    log_cfg = pj.LogConfig()
    log_cfg.level = 2  # Reduce log level to see Python output (1=ERROR, 2=WARNING, 3=INFO, 4=DEBUG)
    log_cfg.consoleLevel = 2
    ep_cfg.logConfig = log_cfg

    ep.libInit(ep_cfg)

    # Create transport
    transport_cfg = pj.TransportConfig()
    transport_cfg.port = 0
    ep.transportCreate(pj.PJSIP_TRANSPORT_UDP, transport_cfg)

    ep.libStart()
    print("PJSUA started")

    # Register extension 202
    print("\n=== Registering extension 202 ===")
    acc_cfg_202 = pj.AccountConfig()
    acc_cfg_202.idUri = f"sip:202@{server_ip}"
    acc_cfg_202.regConfig.registrarUri = f"sip:{server_ip}:5060"
    cred_202 = pj.AuthCredInfo("digest", "*", "202", 0, secret_202)
    acc_cfg_202.sipConfig.authCreds.append(cred_202)

    acc_202 = SimpleAccount()
    acc_202.create(acc_cfg_202)

    # Wait for registration with manual event polling
    import time
    print(f"Initial acc_202.registered = {acc_202.registered}")
    for i in range(10):
        ep.libHandleEvents(100)  # Poll for events (100ms timeout)
        print(f"  Waiting... iteration {i+1}/10, registered={acc_202.registered}")
        time.sleep(0.9)  # Sleep less since libHandleEvents takes ~100ms
        if acc_202.registered:
            print("✓ Extension 202 registered!")
            break
    else:
        print(f"✗ Extension 202 failed to register (final registered={acc_202.registered})")
        return 1

    # Register extension 228
    print("\n=== Registering extension 228 ===")
    acc_cfg_228 = pj.AccountConfig()
    acc_cfg_228.idUri = f"sip:228@{server_ip}"
    acc_cfg_228.regConfig.registrarUri = f"sip:{server_ip}:5060"
    cred_228 = pj.AuthCredInfo("digest", "*", "228", 0, secret_228)
    acc_cfg_228.sipConfig.authCreds.append(cred_228)

    acc_228 = SimpleAccount()
    acc_228.create(acc_cfg_228)

    # Wait for registration with manual event polling
    for i in range(10):
        ep.libHandleEvents(100)  # Poll for events
        time.sleep(0.9)
        if acc_228.registered:
            print("✓ Extension 228 registered!")
            break
    else:
        print("✗ Extension 228 failed to register")
        return 1

    # Make call from 202 to 228
    print("\n=== Making call from 202 to 228 ===")

    # Create call object using SimpleCall class
    call = SimpleCall(acc_202)

    # Prepare call parameters
    call_prm = pj.CallOpParam()
    call_prm.opt.audioCount = 1
    call_prm.opt.videoCount = 0

    # Make the call
    print(f"Calling sip:228@{server_ip}:5060...")
    call.makeCall(f"sip:228@{server_ip}:5060", call_prm)

    # Wait for call to connect using callback flag
    print("Waiting for call to connect...")
    for i in range(15):
        ep.libHandleEvents(100)  # Poll for events
        time.sleep(0.9)
        if call.connected:
            print("✓ Call connected!")
            break
    else:
        print("✗ Call failed to connect within timeout")
        try:
            ci = call.getInfo()
            print(f"  Final state: {ci.stateText}")
            call.hangup(pj.CallOpParam())
        except:
            pass
        return 1

    # Keep call active
    print("Call active, keeping for 5 seconds...")
    time.sleep(5)

    # Hangup
    print("Hanging up...")
    call.hangup(pj.CallOpParam())
    time.sleep(2)

    print("\n✅ Test completed successfully!")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
