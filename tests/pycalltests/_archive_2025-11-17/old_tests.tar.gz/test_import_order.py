#!/usr/bin/env python3
"""Test if importing config before pjsua2 causes issues"""
import sys
import os
from pathlib import Path

# Set library path
pjsua2_lib_path = str(Path(__file__).parent / "pjsua2_lib")
if 'DYLD_LIBRARY_PATH' in os.environ:
    os.environ['DYLD_LIBRARY_PATH'] = f"{pjsua2_lib_path}:{os.environ['DYLD_LIBRARY_PATH']}"
else:
    os.environ['DYLD_LIBRARY_PATH'] = pjsua2_lib_path

sys.path.insert(0, pjsua2_lib_path)
sys.path.insert(0, str(Path(__file__).parent.parent / "api"))

print("Step 1: About to import config")
from config import get_config
print("Step 2: config imported")

print("Step 3: About to import pjsua2")
import pjsua2 as pj
print("Step 4: pjsua2 imported successfully")

print("\n✅ Both imports succeeded!")
