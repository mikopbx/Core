#!/usr/bin/env python3
"""Quick test to verify PJSUA registration works from host"""
import asyncio
from pjsua_helper import PJSUAManager

async def main():
    manager = PJSUAManager(server_ip='192.168.107.2')
    try:
        print("Testing registration from host...")
        await manager.initialize()  # Initialize event handler
        endpoint = await manager.create_endpoint('201', '5b66b92d5714f921cfcde78a4fda0f58', auto_register=True)
        print(f'✓ Registration successful for {endpoint.config.extension}')
        return True
    except Exception as e:
        print(f'✗ Registration failed: {e}')
        import traceback
        traceback.print_exc()
        return False
    finally:
        await manager.cleanup_all()

if __name__ == '__main__':
    result = asyncio.run(main())
    print(f'\nTest result: {"PASSED" if result else "FAILED"}')
    exit(0 if result else 1)
