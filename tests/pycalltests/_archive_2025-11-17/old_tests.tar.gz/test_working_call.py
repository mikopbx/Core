#!/usr/bin/env python3
"""
Working PJSUA Call Test - Based on minimal pattern that works

Tests:
1. Register extensions 202 and 228
2. Make call from 202 to 228
3. Verify call connects
4. Keep call active for 5 seconds
5. Hangup cleanly
"""
import sys
import os
from pathlib import Path
import time
import subprocess

# Set library path
pjsua2_lib_path = str(Path(__file__).parent / "pjsua2_lib")
if 'DYLD_LIBRARY_PATH' in os.environ:
    os.environ['DYLD_LIBRARY_PATH'] = f"{pjsua2_lib_path}:{os.environ['DYLD_LIBRARY_PATH']}"
else:
    os.environ['DYLD_LIBRARY_PATH'] = pjsua2_lib_path

sys.path.insert(0, pjsua2_lib_path)
sys.path.insert(0, str(Path(__file__).parent.parent / "api"))

# Import pjsua2 AFTER setting library path
import pjsua2 as pj

# Import config to get container name
from config import get_config


def get_server_ip():
    """Get MikoPBX server IP from Docker container"""
    config = get_config()
    result = subprocess.run(
        ['docker', 'inspect', '-f', '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}', config.container_name],
        capture_output=True, text=True
    )
    return result.stdout.strip()


def main():
    # Define Account and Call classes INSIDE main() after imports
    # Account class with registration tracking
    class TestAccount(pj.Account):
        def __init__(self):
            pj.Account.__init__(self)
            self.registered = False

        def onRegState(self, prm):
            try:
                ai = self.getInfo()
                print(f"  Registration status: {ai.regStatus}")
                if ai.regStatus == 200:
                    self.registered = True
            except Exception as e:
                print(f"  Error in onRegState: {e}")

    # Call class with state tracking
    class TestCall(pj.Call):
        def __init__(self, account):
            pj.Call.__init__(self, account, pj.PJSUA_INVALID_ID)
            self.connected = False

        def onCallState(self, prm):
            try:
                ci = self.getInfo()
                print(f"  Call state: {ci.stateText}")
                if ci.state == pj.PJSIP_INV_STATE_CONFIRMED:
                    self.connected = True
            except Exception as e:
                print(f"  Error in onCallState: {e}")

    #
    # Extension secrets from fixtures
    secret_202 = "e72b3aea6e4f2a8560adb33cb9bfa5dd"  # brown.brandon (202)
    secret_228 = "bEN4NUw0MEJ4Y1BYMWQ0SUFGTGlXVFFy"  # anton.pasutin (228)

    server_ip = get_server_ip()
    print(f"MikoPBX server IP: {server_ip}", flush=True)

    # Initialize PJSUA endpoint
    print("\n=== Initializing PJSUA ===", flush=True)
    ep = pj.Endpoint()
    ep.libCreate()
    print("✓ Endpoint created", flush=True)

    ep_cfg = pj.EpConfig()
    ep_cfg.uaConfig.maxCalls = 10
    ep_cfg.uaConfig.threadCnt = 0
    ep_cfg.uaConfig.mainThreadOnly = True
    print("✓ Config created", flush=True)

    log_cfg = pj.LogConfig()
    log_cfg.level = 3
    log_cfg.consoleLevel = 0  # Disable console logging to see Python prints clearly
    ep_cfg.logConfig = log_cfg
    print("✓ Log config set", flush=True)

    print("About to call libInit()...", flush=True)
    ep.libInit(ep_cfg)
    print("✓ libInit() completed", flush=True)

    # Create transport
    print("About to create transport...", flush=True)
    transport_cfg = pj.TransportConfig()
    transport_cfg.port = 0
    ep.transportCreate(pj.PJSIP_TRANSPORT_UDP, transport_cfg)
    print("✓ Transport created", flush=True)

    # Start PJSUA
    print("About to call libStart()...", flush=True)
    ep.libStart()
    print("✓ PJSUA started", flush=True)

    # Register extension 202
    print("\n=== Registering extension 202 ===", flush=True)
    acc_cfg_202 = pj.AccountConfig()
    acc_cfg_202.idUri = f"sip:202@{server_ip}"
    acc_cfg_202.regConfig.registrarUri = f"sip:{server_ip}:5060"
    cred_202 = pj.AuthCredInfo("digest", "*", "202", 0, secret_202)
    acc_cfg_202.sipConfig.authCreds.append(cred_202)
    print("Creating TestAccount...", flush=True)

    acc_202 = TestAccount()
    print("Calling acc_202.create()...", flush=True)
    acc_202.create(acc_cfg_202)
    print("✓ Account 202 created", flush=True)

    # Wait for registration with event polling
    print("Waiting for registration...", flush=True)
    for i in range(10):
        print(f"  Polling events (iteration {i+1})...", flush=True)
        ep.libHandleEvents(100)
        time.sleep(0.9)
        if acc_202.registered:
            print("✓ Extension 202 registered", flush=True)
            break
    else:
        print("✗ Extension 202 failed to register", flush=True)
        return 1

    # Register extension 228
    print("\n=== Registering extension 228 ===")
    acc_cfg_228 = pj.AccountConfig()
    acc_cfg_228.idUri = f"sip:228@{server_ip}"
    acc_cfg_228.regConfig.registrarUri = f"sip:{server_ip}:5060"
    cred_228 = pj.AuthCredInfo("digest", "*", "228", 0, secret_228)
    acc_cfg_228.sipConfig.authCreds.append(cred_228)

    acc_228 = TestAccount()
    acc_228.create(acc_cfg_228)

    # Wait for registration with event polling
    for i in range(10):
        ep.libHandleEvents(100)
        time.sleep(0.9)
        if acc_228.registered:
            print("✓ Extension 228 registered")
            break
    else:
        print("✗ Extension 228 failed to register")
        return 1

    # Make call from 202 to 228
    print("\n=== Making call from 202 to 228 ===")

    # Create call object AFTER libStart() and account registration
    call = TestCall(acc_202)

    call_prm = pj.CallOpParam()
    call_prm.opt.audioCount = 1
    call_prm.opt.videoCount = 0

    print(f"Calling sip:228@{server_ip}:5060...")
    call.makeCall(f"sip:228@{server_ip}:5060", call_prm)

    # Wait for call to connect
    print("Waiting for call to connect...")
    for i in range(15):
        ep.libHandleEvents(100)
        time.sleep(0.9)
        if call.connected:
            print("✓ Call connected!")
            break
    else:
        print("✗ Call failed to connect within 15 seconds")
        try:
            call.hangup(pj.CallOpParam())
        except:
            pass
        return 1

    # Keep call active
    print("Call active, keeping for 5 seconds...")
    for i in range(5):
        ep.libHandleEvents(100)
        time.sleep(0.9)

    # Hangup
    print("Hanging up...")
    call.hangup(pj.CallOpParam())

    # Give time for hangup to complete
    for i in range(2):
        ep.libHandleEvents(100)
        time.sleep(0.9)

    print("\n✅ Test completed successfully!")
    print("Both extensions registered and call was established")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
