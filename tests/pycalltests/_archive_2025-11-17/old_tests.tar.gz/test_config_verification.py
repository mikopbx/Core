#!/usr/bin/env python3
"""
PJSUA Configuration and Environment Verification Tests

This module verifies that the test environment is properly configured:
1. PJSUA library can be imported successfully
2. MikoPBX container is accessible and responsive
3. Test extensions (201, 202, 203) exist and are properly configured
4. SIP hostname is correctly resolved

These tests should run before any call flow tests to ensure the environment is ready.
"""

import sys
import logging
import pytest
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Add pjsua2_lib to path
pjsua2_lib_path = str(Path(__file__).parent / "pjsua2_lib")
sys.path.insert(0, pjsua2_lib_path)


def test_pjsua_library_import():
    """
    Test that PJSUA library can be imported successfully

    This test verifies:
    1. pjsua2 module is available in pjsua2_lib directory
    2. Module can be imported without errors
    3. Basic PJSUA classes are accessible

    Expected behavior:
    - Import succeeds without ImportError
    - Endpoint class is available
    - Version information can be retrieved
    """
    logger.info("=" * 80)
    logger.info("TEST: PJSUA Library Import")
    logger.info("=" * 80)

    try:
        # Import pjsua2 module
        logger.info("Importing pjsua2 module")
        import pjsua2 as pj
        logger.info("✓ pjsua2 module imported successfully")

        # Check basic classes are available
        logger.info("Checking PJSUA classes availability")
        assert hasattr(pj, 'Endpoint'), "Endpoint class should be available"
        assert hasattr(pj, 'Account'), "Account class should be available"
        assert hasattr(pj, 'Call'), "Call class should be available"
        assert hasattr(pj, 'AccountConfig'), "AccountConfig class should be available"
        logger.info("✓ All required PJSUA classes are available")

        # Get PJSUA version
        logger.info("Retrieving PJSUA version")
        ep = pj.Endpoint()
        ep.libCreate()
        version = ep.libVersion()
        logger.info(f"✓ PJSUA Version: {version.full}")
        ep.libDestroy()

    except ImportError as e:
        logger.error(f"✗ Failed to import pjsua2: {e}")
        pytest.fail(f"PJSUA library import failed: {e}")
    except Exception as e:
        logger.error(f"✗ Error during PJSUA verification: {e}")
        pytest.fail(f"PJSUA verification failed: {e}")

    logger.info("=" * 80)
    logger.info("TEST PASSED: PJSUA Library Import")
    logger.info("=" * 80)


@pytest.mark.asyncio
async def test_mikopbx_connectivity(api_client):
    """
    Test that MikoPBX container is accessible and responsive

    This test verifies:
    1. API client can connect to MikoPBX
    2. Authentication succeeds
    3. System status endpoint is accessible
    4. License endpoint responds

    Expected behavior:
    - API connection succeeds
    - License information is returned
    - System is responsive
    """
    logger.info("=" * 80)
    logger.info("TEST: MikoPBX Connectivity")
    logger.info("=" * 80)

    # Test license endpoint (requires authentication)
    logger.info("Testing license endpoint")
    license_response = api_client.get('license')

    assert license_response.get('result') is True, "License endpoint should return success"
    logger.info(f"✓ License endpoint accessible")
    logger.info(f"  License data: {license_response.get('data', {})}")

    # Test system status
    logger.info("Testing system ping")
    ping_response = api_client.get('system/ping')

    # Ping endpoint may not exist, so we just check if we got a response
    logger.info(f"✓ System ping response: {ping_response}")

    logger.info("=" * 80)
    logger.info("TEST PASSED: MikoPBX Connectivity")
    logger.info("=" * 80)


@pytest.mark.asyncio
async def test_extension_configuration(api_client):
    """
    Test that test extensions are properly configured

    This test verifies:
    1. Extensions 201, 202, 203 exist in MikoPBX
    2. Each extension has a valid SIP secret
    3. Extensions are enabled
    4. Extension data matches fixture expectations

    Expected behavior:
    - All test extensions exist
    - SIP secrets are valid MD5 hashes
    - Extensions are enabled and ready for testing
    """
    from conftest import get_extension_secret

    logger.info("=" * 80)
    logger.info("TEST: Extension Configuration")
    logger.info("=" * 80)

    test_extensions = ['201', '202', '203']
    extension_data = {}

    for ext in test_extensions:
        logger.info(f"Checking extension {ext}")

        # Get extension secret
        secret = get_extension_secret(ext, api_client)

        if not secret:
            logger.warning(f"  ⚠️  Extension {ext} not found (will be created on demand)")
            continue

        # Verify secret is valid MD5 hash (32 hex characters)
        assert len(secret) == 32, f"Extension {ext} secret should be 32 characters"
        assert all(c in '0123456789abcdef' for c in secret.lower()), \
            f"Extension {ext} secret should be valid MD5 hash"

        extension_data[ext] = secret
        logger.info(f"  ✓ Extension {ext}: {secret}")

    if extension_data:
        logger.info(f"✓ Found {len(extension_data)} configured extensions")
    else:
        logger.info("⚠️  No extensions configured yet (will be created on demand)")

    logger.info("=" * 80)
    logger.info("TEST PASSED: Extension Configuration")
    logger.info("=" * 80)


@pytest.mark.asyncio
async def test_sip_hostname_resolution():
    """
    Test that SIP hostname is correctly configured and resolvable

    This test verifies:
    1. SIP hostname can be retrieved from config
    2. Hostname format is correct
    3. Hostname is suitable for SIP registration

    Expected behavior:
    - SIP hostname is configured
    - Hostname follows expected format
    - Hostname can be used for SIP connections
    """
    from pjsua_helper import get_mikopbx_ip

    logger.info("=" * 80)
    logger.info("TEST: SIP Hostname Resolution")
    logger.info("=" * 80)

    # Get SIP hostname
    logger.info("Retrieving SIP hostname from config")
    sip_hostname = await get_mikopbx_ip()

    assert sip_hostname, "SIP hostname should not be empty"
    logger.info(f"✓ SIP hostname: {sip_hostname}")

    # Verify hostname format
    assert '.' in sip_hostname, "SIP hostname should contain domain"
    logger.info(f"✓ Hostname format is valid")

    # Check if it's a local development hostname
    if '.dev-docker.orb.local' in sip_hostname or '.localhost' in sip_hostname:
        logger.info(f"✓ Local development hostname detected")
    else:
        logger.info(f"✓ Remote or custom hostname detected")

    logger.info("=" * 80)
    logger.info("TEST PASSED: SIP Hostname Resolution")
    logger.info("=" * 80)


if __name__ == '__main__':
    # Run tests directly with pytest
    pytest.main([__file__, '-v', '-s'])
