# PyCallTests Configuration Refactoring Summary

## Date: 2025-11-14

## Objective
Remove all hardcoded container names and IP addresses from pycalltests, integrate with existing `config.py` system from API tests.

## Changes Made

### 1. Environment Configuration (.env)
**File:** `tests/api/.env`

**Change:** Fixed container name to match actual Docker container
```bash
# Before:
MIKOPBX_CONTAINER=mikopbx-modules-api-refactoring

# After:
MIKOPBX_CONTAINER=mikopbx_modules-api-refactoring
```

**Reason:** Actual container uses underscore, not hyphen

---

### 2. GoPhone Helper Integration
**File:** `tests/pycalltests/gophone_helper.py`

**Changes:**
- Added `config.py` import and integration
- Updated `get_mikopbx_ip()` to use dynamic container name from config
- Removed hardcoded `mikopbx-php83` container name
- Removed hardcoded IP fallback `192.168.107.3`

**Before:**
```python
async def get_mikopbx_ip() -> str:
    container_name = "mikopbx-php83"  # Hardcoded
    # ... docker inspect ...
    return ip or "192.168.107.3"  # Hardcoded fallback
```

**After:**
```python
async def get_mikopbx_ip() -> str:
    config = get_config()
    container_name = config.container_name  # Dynamic from .env
    # ... docker inspect ...
    # Raises exception if container not found (no hardcoded fallback)
```

---

### 3. Asterisk Helper Integration
**File:** `tests/pycalltests/helpers/asterisk_helper.py`

**Changes:**
- Added `config.py` import
- Updated 11 functions to use `Optional[str] = None` with config fallback
- Removed all hardcoded `mikopbx-php83` default values

**Affected functions:**
1. `exec_asterisk_cli()`
2. `get_active_channels()`
3. `get_channel_codec()`
4. `check_moh_playing()`
5. `check_parking_lot()`
6. `get_bridged_channel()`
7. `get_channel_state()`
8. `wait_for_channel_state()`
9. `originate_call()`
10. `hangup_channel()`
11. `send_dtmf()`

**Pattern:**
```python
# Before:
def exec_asterisk_cli(command: str, container_name: str = 'mikopbx-php83', timeout: int = 10) -> str:

# After:
def exec_asterisk_cli(command: str, container_name: Optional[str] = None, timeout: int = 10) -> str:
    if container_name is None:
        container_name = get_config().container_name
```

---

### 4. Test Files Updates
**Files:** All test files (test_66-71)

**Changes:**
- `test_66_ivr_navigation.py`: Removed hardcoded values from asterisk_helper calls
- `test_67_voicemail.py`: Updated `validate_audio_in_container()`, `find_voicemail_file()`, docker exec
- `test_68_call_parking.py`: Updated `check_parking_lot()`, `get_active_channels()`, `get_bridged_channel()`
- `test_69_music_on_hold.py`: Updated `get_active_channels()`, `check_moh_playing()`, docker exec
- `test_70_call_recording.py`: Updated to use `config.container_name` variable
- `test_71_codec_negotiation.py`: Removed explicit container_name parameters

**Example changes:**
```python
# Before:
channels = get_active_channels('mikopbx-php83')
codec = get_channel_codec(ch['channel'], 'mikopbx-php83')

# After:
channels = get_active_channels()  # Uses config
codec = get_channel_codec(ch['channel'])  # Uses config
```

---

### 5. Conftest Fixtures Integration
**File:** `tests/pycalltests/conftest.py`

**Changes:**
- Fixed import mechanism to properly load API conftest
- Added missing utility function exports:
  - `assert_api_success`
  - `get_extension_secret`
  - `convert_employee_fixture_to_api_format`

**Before:**
```python
__all__ = [
    'api_client',
    'cdr_baseline',
    'MikoPBXClient'
]
```

**After:**
```python
# Re-export utility functions
assert_api_success = api_conftest.assert_api_success
get_extension_secret = api_conftest.get_extension_secret
convert_employee_fixture_to_api_format = api_conftest.convert_employee_fixture_to_api_format

__all__ = [
    'api_client',
    'cdr_baseline',
    'MikoPBXClient',
    'assert_api_success',
    'get_extension_secret',
    'convert_employee_fixture_to_api_format'
]
```

---

## Verification

### Configuration Loading
```bash
$ python3 tests/pycalltests/test_config_verification.py
✓ Config loaded successfully
  API URL: https://mikopbx-modules-api-refactoring.dev-docker.orb.local:8459/pbxcore/api/v3
  Container: mikopbx_modules-api-refactoring
  Username: admin
✅ Configuration is valid
```

### Container Verification
```bash
$ docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' mikopbx_modules-api-refactoring
192.168.107.4
```

### Test Collection
```bash
$ python3 -m pytest tests/pycalltests/test_6[6-9]*.py tests/pycalltests/test_70*.py tests/pycalltests/test_71*.py --collect-only
========================= 20 tests collected in 0.04s ==========================
```

**Tests collected successfully:**
- test_66_ivr_navigation.py: 3 tests
- test_67_voicemail.py: 3 tests
- test_68_call_parking.py: 3 tests
- test_69_music_on_hold.py: 3 tests
- test_70_call_recording.py: 3 tests
- test_71_codec_negotiation.py: 5 tests

---

## Impact Summary

### Removed Hardcoded Values
- ❌ Container name: `mikopbx-php83` (67+ occurrences removed)
- ❌ IP address: `192.168.107.3` (1 fallback removed)

### Added Dynamic Configuration
- ✅ All container references now use `config.container_name` from `.env`
- ✅ All IP lookups use dynamic Docker inspect via `get_mikopbx_ip()`
- ✅ Centralized configuration in `tests/api/.env`

### Benefits
1. **Flexibility**: Change container name in one place (.env file)
2. **Consistency**: Same config system as API tests
3. **Maintainability**: No scattered hardcoded values
4. **Error clarity**: Explicit exceptions instead of silent fallbacks

---

---

## PJSUA Integration (Added: 2025-11-16)

### Overview
Replaced GoPhone CLI tool with PJSUA2 Python library for SIP testing. PJSUA provides native Python bindings with full SIP protocol support, proper CDR record creation, and standard recording file naming.

### Why PJSUA?
**Previous issues with GoPhone:**
- Calls didn't create proper CDR records
- Recording files used non-standard naming
- Limited SIP feature support
- Process management complexity (subprocess handling)

**PJSUA advantages:**
- Native Python library (no subprocess management)
- Full PJSIP stack support
- Proper call flow creates CDR records
- Standard SIP behavior
- Callback-based async architecture

### Implementation

#### 1. PJSUA Library Compilation
**Location:** `tests/pycalltests/pjsua2_lib/`

Compiled PJSIP 2.15.1 with Python SWIG bindings for macOS (arm64):
```bash
./configure --enable-shared
make dep && make
cd pjsip-apps/src/swig
make
```

**Files included:**
- `_pjsua2.so` - Native PJSIP library
- `pjsua2.py` - Python wrapper
- Dynamic libraries: `libpj.dylib`, `libpjsip.dylib`, `libpjsua2.dylib`, etc.

#### 2. PJSUA Helper Module
**File:** `tests/pycalltests/pjsua_helper.py`

**Architecture:**
```
PJSUAManager (Singleton)
  ├── Initializes PJSIP Endpoint (once)
  ├── Creates UDP transport
  └── Manages multiple PJSUAEndpoint instances

PJSUAEndpoint (Per Extension)
  ├── PJSUAAccountCallback (Registration)
  └── PJSUACallCallback (Call state)
```

**Key Classes:**

1. **PJSUAConfig** - Configuration dataclass
   - extension: SIP extension number
   - password: MD5 SIP secret
   - server_ip: MikoPBX hostname
   - server_port: SIP port (default: 5060)

2. **PJSUAAccountCallback** - Handles registration events
   - `onRegState()` - Registration status changes
   - Uses asyncio futures for async/await pattern

3. **PJSUACallCallback** - Handles call events
   - `onCallState()` - Call state changes (CONFIRMED, DISCONNECTED)
   - `onCallMediaState()` - Media connection setup

4. **PJSUAEndpoint** - Represents single SIP endpoint
   - `register()` - Register to MikoPBX
   - `dial()` - Make outbound call
   - `send_dtmf()` - Send DTMF tones
   - `hangup()` - End call
   - `unregister()` - Unregister

5. **PJSUAManager** - Manages multiple endpoints
   - Singleton PJSIP Endpoint initialization
   - Thread-safe endpoint creation
   - Cleanup coordination

**Integration with config.py:**
```python
async def get_mikopbx_ip() -> str:
    config = get_config()
    return config.sip_hostname
```

#### 3. Test Files

**test_pjsua_basic.py** - Basic functionality tests
- `test_pjsua_registration()` - Verify SIP registration
  - Extension 201 registers successfully
  - Registration status confirmed
  - Unregistration works

- `test_pjsua_basic_call()` - Verify call flow
  - Extensions 201 and 202 register
  - Call from 201 to 202 succeeds
  - Call reaches CONFIRMED state
  - CDR record is created
  - Hangup completes cleanly

**test_config_verification.py** - Environment verification
- `test_pjsua_library_import()` - Verify PJSUA can be imported
  - Module loads successfully
  - Required classes available
  - Version information accessible

- `test_mikopbx_connectivity()` - Verify MikoPBX is accessible
  - API connection works
  - Authentication succeeds
  - License endpoint responds

- `test_extension_configuration()` - Verify test extensions
  - Extensions 201, 202, 203 exist
  - SIP secrets are valid MD5 hashes
  - Extensions ready for testing

- `test_sip_hostname_resolution()` - Verify SIP configuration
  - SIP hostname is configured
  - Hostname format is valid
  - Suitable for SIP connections

#### 4. Extension Management

**Fixture Integration:**
Tests use `tests/api/fixtures/employee.json` for extension data:
```json
{
  "smith.james": {
    "number": 201,
    "secret": "5b66b92d5714f921cfcde78a4fda0f58"
  },
  "brown.brandon": {
    "number": 202,
    "secret": "e72b3aea6e4f2a8560adb33cb9bfa5dd"
  }
}
```

**Auto-creation logic:**
```python
async def ensure_extension_exists(api_client, extension_number: str) -> str:
    # Try to get secret from existing extension
    secret = get_extension_secret(extension_number, api_client)

    if secret:
        return secret

    # Extension doesn't exist, create from fixture
    extension_data = convert_employee_fixture_to_api_format(employee_key)
    api_client.post('extensions/create', extension_data)
    return get_extension_secret(extension_number, api_client)
```

### Usage Example

```python
from pjsua_helper import PJSUAManager, get_mikopbx_ip

# Create manager
server_ip = await get_mikopbx_ip()
manager = PJSUAManager(server_ip)

# Create and register endpoint
endpoint = await manager.create_endpoint(
    extension="201",
    password="5b66b92d5714f921cfcde78a4fda0f58",
    auto_register=True
)

# Make call
call_result = await endpoint.dial(destination="202", timeout=30)

# Send DTMF
await endpoint.send_dtmf("123")

# Hangup
await endpoint.hangup()

# Cleanup
await manager.cleanup_all()
```

### Backward Compatibility

For gradual migration, aliases are provided:
```python
GoPhoneConfig = PJSUAConfig
GoPhoneEndpoint = PJSUAEndpoint
GoPhoneManager = PJSUAManager
```

This allows existing tests using GoPhone to continue working while transitioning to PJSUA.

### Running PJSUA Tests

**Important:** On macOS, you must set `DYLD_LIBRARY_PATH` to the pjsua2_lib directory for dynamic library loading:

```bash
# Set library path and run all PJSUA tests
cd tests/pycalltests && DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest test_pjsua_basic.py -v -s

# Run configuration verification
cd tests/pycalltests && DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest test_config_verification.py -v -s

# Run specific test
cd tests/pycalltests && DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest test_pjsua_basic.py::test_pjsua_registration -v -s

# Alternative: Set from project root
DYLD_LIBRARY_PATH=tests/pycalltests/pjsua2_lib python3 -m pytest tests/pycalltests/test_pjsua_basic.py -v -s
```

**Note:** The `DYLD_LIBRARY_PATH` environment variable tells macOS where to find the PJSIP dynamic libraries (libpj.dylib, libpjsip.dylib, etc.).

### Benefits

1. **Proper CDR Records**: PJSUA calls create standard CDR entries in `/storage/usbdisk1/mikopbx/astlogs/asterisk/cdr.db`
2. **Standard Recordings**: Recording files follow MikoPBX naming: `monitor/*-{src}-{dst}-*.wav`
3. **Full SIP Support**: Complete PJSIP stack with all SIP features
4. **No Process Management**: Pure Python library, no subprocess coordination
5. **Async/Await**: Native asyncio integration with futures
6. **Type Safety**: Python dataclasses for configuration
7. **Comprehensive Logging**: Detailed logging at DEBUG level for troubleshooting

---

## Next Steps

Tests are now ready to run. To execute:

```bash
# Run all advanced call flow tests
python3 -m pytest tests/pycalltests/test_6[6-9]*.py tests/pycalltests/test_70*.py tests/pycalltests/test_71*.py -v

# Run PJSUA verification tests (with library path on macOS)
cd tests/pycalltests && DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest test_config_verification.py test_pjsua_basic.py -v -s

# Run specific test
cd tests/pycalltests && DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest test_71_codec_negotiation.py::test_01_verify_enabled_codecs -v -s
```

**Note:** Tests require:
- Extensions 201, 202, 203 to be configured in MikoPBX (auto-created if missing)
- PJSUA library in `tests/pycalltests/pjsua2_lib/` directory
- Active MikoPBX container with REST API enabled
- **macOS only:** `DYLD_LIBRARY_PATH` environment variable set to pjsua2_lib directory

---

## PJSUA2 Migration: Docker Container to Local Host (Updated: 2025-11-17)

### Problem Identification

Initial PJSUA2 implementation used Docker container for test execution but encountered a critical authentication issue:

**Symptom:** SIP registration failed with "401 Unauthorized" - PJSUA was not sending credentials in response to authentication challenges.

**Observed via tcpdump:**
```
05:56:47 - REGISTER sent without Authorization header
05:56:47 - 401 Unauthorized received with WWW-Authenticate: Digest realm="asterisk"
          - No second REGISTER with Authorization header sent
```

### Root Cause Analysis

The issue was NOT a protocol-level problem, but rather improper credential configuration in PJSUA2 Python bindings.

**Problem:** PJSUA2 Python bindings don't properly handle wildcard realm matching.

When Asterisk sends:
```
WWW-Authenticate: Digest realm="asterisk",nonce="...",algorithm=MD5,qop="auth"
```

PJSUA2 Python requires **exact realm matching**. Using wildcard realm `"*"` does NOT work:

```python
# ❌ BROKEN - Wildcard realm doesn't match
cred = pj.AuthCredInfo("digest", "*", extension, 0, password)

# ✅ FIXED - Use Asterisk's actual realm
cred = pj.AuthCredInfo("digest", "asterisk", extension, 0, password)
```

**File:** `pjsua_helper.py:180`

### Architecture Change: Container to Local Execution

**Previous Approach (Docker Container):**
- Tests ran inside Docker container
- Required building custom container with PJSUA
- Complex Dockerfile with compilation dependencies
- docker-compose.yml for container orchestration
- Slower iteration cycle (rebuild container for changes)

**New Approach (Local Host Execution):**
- Tests run on macOS host (development machine)
- Pre-compiled PJSUA2 libraries in `pjsua2_lib/`
- Connect to MikoPBX container via Docker network
- No container build required
- Faster development iteration

**Network Architecture:**
```
┌─────────────────────────┐         ┌──────────────────────┐
│  PJSUA2 Client          │         │  MikoPBX Container   │
│  macOS Host             │         │  Docker              │
│  192.168.107.0          │─────────│  192.168.107.2       │
│  (Developer Machine)    │  SIP    │  mikopbx_tests-*     │
└─────────────────────────┘  5060   └──────────────────────┘
```

### Changes Made

#### 1. Removed Docker Infrastructure

**Files deleted:**
- `Dockerfile` - No longer needed, using pre-compiled libraries
- `docker-compose.yml` - Tests run locally, not in container

**Before:** Complex multi-stage Dockerfile
```dockerfile
FROM python:3.11-slim
RUN apt-get update && apt-get install -y \
    build-essential cmake git ... [many deps]
WORKDIR /pjproject
RUN git clone https://github.com/pjsip/pjproject.git .
RUN ./configure --enable-shared ...
RUN make dep && make && make install
...
```

**After:** Simple local execution
```bash
# Pre-compiled libraries already in pjsua2_lib/
DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest
```

#### 2. Authentication Fix

**File:** `pjsua_helper.py:180`

```python
# Create authentication credentials with CORRECT realm
cred = pj.AuthCredInfo(
    "digest",           # scheme
    "asterisk",         # realm - MUST be exact, NOT wildcard "*"
    self.config.extension,  # username
    0,                  # data_type (0 = plaintext)
    self.config.password    # password
)
self.acc.setCredentials([cred])
```

**Why this is critical:**
- PJSUA2 C++ library supports wildcard realm matching
- PJSUA2 Python bindings don't properly implement this feature
- Must specify exact realm that Asterisk uses: `"asterisk"`
- Wildcard `"*"` results in credentials not being sent on 401 challenge

#### 3. Test Execution Method

**Before (Container):**
```bash
docker-compose build pjsua-tests
docker-compose run pjsua-tests pytest test_registration_and_echo.py
```

**After (Local Host):**
```bash
cd tests/pycalltests
DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest test_registration_and_echo.py -v
```

#### 4. Library Loading

**macOS Dynamic Library Path:**
```bash
# Set library path for PJSUA2 dylibs
export DYLD_LIBRARY_PATH=/path/to/tests/pycalltests/pjsua2_lib

# Or inline with test command
DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest
```

**Libraries loaded:**
- `_pjsua2.so` - Python SWIG extension
- `libpj.dylib` - PJSIP core library
- `libpjsip.dylib` - SIP protocol implementation
- `libpjsip-ua.dylib` - SIP user agent
- `libpjsua2.dylib` - C++ API wrapper
- `libpjmedia.dylib` - Media handling
- `libpjnath.dylib` - NAT traversal

### Test Results After Fix

**UDP Registration:**
```
test_registration_by_transport[udp] PASSED
```

**TCP Registration:**
```
test_registration_by_transport[tcp] PASSED
```

**Authentication Flow (tcpdump verification):**
```
06:12:34 - REGISTER sent without auth
06:12:34 - 401 Unauthorized with WWW-Authenticate: Digest realm="asterisk"
06:12:34 - REGISTER sent WITH Authorization header  ✅ FIXED
06:12:34 - 200 OK registration successful
```

### Benefits of Local Execution

1. **Faster Development:**
   - No container rebuild on code changes
   - Immediate test execution
   - Direct debugging with IDE

2. **Simpler Setup:**
   - No Docker complexity
   - Pre-compiled libraries
   - Standard pytest workflow

3. **Better Debugging:**
   - Native macOS debugging tools
   - Direct log access
   - Easier tcpdump analysis

4. **Consistent Results:**
   - Fixed authentication works reliably
   - No container environment variables
   - Standard network routing

### Migration Notes

**For other developers:**

If you need to compile PJSUA2 for your platform:

```bash
# Download PJSIP
git clone https://github.com/pjsip/pjproject.git
cd pjproject

# Configure with shared libraries
./configure --enable-shared --disable-video

# Build
make dep && make

# Build Python bindings
cd pjsip-apps/src/swig
make python

# Copy to project
cp -r python/* /path/to/tests/pycalltests/pjsua2_lib/
```

**Platform-specific library loading:**
- **macOS**: `DYLD_LIBRARY_PATH`
- **Linux**: `LD_LIBRARY_PATH`
- **Windows**: PATH or system32 directory

### Known Limitations

1. **TLS Transport:** Requires additional PJSUA configuration (not yet implemented)
   - Test `test_registration_tls` is skipped
   - Needs TLS transport creation with certificates
   - Port configuration for 5061

2. **Platform Dependency:** Pre-compiled libraries are macOS ARM64 specific
   - Other platforms need separate compilation
   - Consider adding Linux x86_64 libraries for CI/CD

3. **Library Path Requirement:** Must set DYLD_LIBRARY_PATH for every test run
   - Could be automated with shell wrapper script
   - Or pytest plugin to set environment

### Verification Commands

```bash
# Test PJSUA2 import
DYLD_LIBRARY_PATH=pjsua2_lib python3 -c "import pjsua2 as pj; print('OK')"

# Run registration tests
DYLD_LIBRARY_PATH=pjsua2_lib python3 -m pytest test_registration_and_echo.py -v

# Monitor SIP traffic
docker exec mikopbx_tests-refactoring tcpdump -i any -n port 5060 -A

# Check Asterisk logs for authentication
docker exec mikopbx_tests-refactoring tail -f /storage/usbdisk1/mikopbx/log/asterisk/messages | grep REGISTER
```

---
